(function(window, undefined) {
  var dictionary = {
    "ac50fc10-8047-4d4b-af81-1f247b5521e9": "Tela1-estagiario",
    "a4a2cb6f-8485-4418-842a-b76db19aa1cb": "NotificaçõesRESCISÃO",
    "3ad89b18-1b2f-4cdb-8b16-539dcf5a29d6": "DadosEstagiarios",
    "e4df34a7-e082-4172-b666-bc3552a6a06f": "NotificaçõesFERIAS",
    "b3d47cbe-2b79-4d5d-b69c-35edd0509267": "Notifica",
    "6cdbc05b-8711-40da-8fde-1d5dbf432ed3": "TrocarSenha",
    "411aa969-ebe9-4a4a-bdb8-aa1ae7261e56": "ConsultarEstagiarios",
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "Login",
    "bddd6c56-6e5e-4450-a606-2de09954a559": "Tela1-Servidor",
    "b0a8598c-16e9-4231-8bdf-3e30f16e01df": "Notificações",
    "8948928c-62d1-4fd3-bfe3-dbc70c2dc134": "Rescisao",
    "7ce23c92-760c-433a-bab0-872a1a3a91b2": "Cadastro Estagiarios",
    "87db3cf7-6bd4-40c3-b29c-45680fb11462": "960 grid - 16 columns",
    "e5f958a4-53ae-426e-8c05-2f7d8e00b762": "960 grid - 12 columns",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "default"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);