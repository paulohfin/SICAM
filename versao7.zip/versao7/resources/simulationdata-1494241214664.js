function initData() {
  jimData.variables["TIPOLOGIN"] = "";
  jimData.variables["EDIT"] = "";
  jimData.variables["USER"] = "";
  jimData.variables["SELECTESTAGIARIO"] = "";
  jimData.datamasters["Gabinete"] = [
    {
      "id": 1,
      "datamaster": "Gabinete",
      "userdata": {
        "Nome": "GABINETE1"
      }
    },
    {
      "id": 2,
      "datamaster": "Gabinete",
      "userdata": {
        "Nome": "GABINETE2"
      }
    },
    {
      "id": 3,
      "datamaster": "Gabinete",
      "userdata": {
        "Nome": "GABINETE3"
      }
    }
  ];

  jimData.datamasters["Estagiario"] = [
    {
      "id": 1,
      "datamaster": "Estagiario",
      "userdata": {
        "NOME": "TESTE1",
        "CPF": "12345",
        "TELEFONE1": "3333-5555",
        "TELEFONE2": "",
        "ENDERECO": "RUA CENTRAL",
        "COMPLEMENTO": "QUADRA ZERO",
        "SETOR": "CENTRO",
        "BANCO": "CAIXA",
        "AGENCIA": "1234",
        "OPERACAO": "123",
        "CONTA": "33333-5",
        "CURSO": "MUSICA",
        "INSTITUICAO": "UNIP",
        "INICIOCONTRATO": "10/12/2016",
        "TERMINOCONTRATO": "09/12/2017",
        "VALORESTAGIO": "875.00",
        "LOTACAO": "GABINETE1",
        "SUPERVISOR": "ABADIA",
        "CONVENIO": "CIEE",
        "LOGIN": "EST1",
        "SENHA": "123456",
        "SITUACAOCONTRATO": "CONTRATADO",
        "CONVENIOANTERIOR": "",
        "DATAINICIOANTERIOR": "",
        "DATAFIMANTERIOR": "",
        "VALOR": "sample text",
        "INICIOFERIAS": "",
        "TERMINOFERIAS": ""
      }
    }
  ];

  jimData.datamasters["Servidor"] = [
    {
      "id": 1,
      "datamaster": "Servidor",
      "userdata": {
        "NOME": "ABADIA",
        "CPF": "123.456.789-10",
        "LOGIN": "SERV1",
        "SENHA": "123456",
        "LOTACAO": "GABINETE1",
        "QUANTIDADEESTAGIARIO": "5"
      }
    },
    {
      "id": 2,
      "datamaster": "Servidor",
      "userdata": {
        "NOME": "BERNADETE",
        "CPF": "555.444.333-12",
        "LOGIN": "SERV2",
        "SENHA": "123456",
        "LOTACAO": "GABINETE2",
        "QUANTIDADEESTAGIARIO": "5"
      }
    },
    {
      "id": 3,
      "datamaster": "Servidor",
      "userdata": {
        "NOME": "CAMILA",
        "CPF": "444.555.444-12",
        "LOGIN": "SERV3",
        "SENHA": "123456",
        "LOTACAO": "GABINETE3",
        "QUANTIDADEESTAGIARIO": "5"
      }
    }
  ];

  jimData.isInitialized = true;
}