(function(window, undefined) {

  var jimLinks = {
    "ac50fc10-8047-4d4b-af81-1f247b5521e9" : {
      "Button_2" : [
        "411aa969-ebe9-4a4a-bdb8-aa1ae7261e56"
      ],
      "Category_1" : [
        "6cdbc05b-8711-40da-8fde-1d5dbf432ed3",
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Button_3" : [
        "b3d47cbe-2b79-4d5d-b69c-35edd0509267"
      ]
    },
    "a4a2cb6f-8485-4418-842a-b76db19aa1cb" : {
      "Category_1" : [
        "6cdbc05b-8711-40da-8fde-1d5dbf432ed3",
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Current_row_1" : [
        "8948928c-62d1-4fd3-bfe3-dbc70c2dc134"
      ],
      "Button_6" : [
        "bddd6c56-6e5e-4450-a606-2de09954a559",
        "ac50fc10-8047-4d4b-af81-1f247b5521e9"
      ]
    },
    "3ad89b18-1b2f-4cdb-8b16-539dcf5a29d6" : {
      "Button_4" : [
        "3ad89b18-1b2f-4cdb-8b16-539dcf5a29d6"
      ],
      "Button_6" : [
        "bddd6c56-6e5e-4450-a606-2de09954a559",
        "ac50fc10-8047-4d4b-af81-1f247b5521e9"
      ],
      "Category_1" : [
        "6cdbc05b-8711-40da-8fde-1d5dbf432ed3",
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Button_1" : [
        "bddd6c56-6e5e-4450-a606-2de09954a559",
        "ac50fc10-8047-4d4b-af81-1f247b5521e9"
      ],
      "Button_5" : [
        "bddd6c56-6e5e-4450-a606-2de09954a559"
      ],
      "Button_2" : [
        "8948928c-62d1-4fd3-bfe3-dbc70c2dc134"
      ]
    },
    "e4df34a7-e082-4172-b666-bc3552a6a06f" : {
      "Category_1" : [
        "6cdbc05b-8711-40da-8fde-1d5dbf432ed3",
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Current_row_1" : [
        "8948928c-62d1-4fd3-bfe3-dbc70c2dc134"
      ],
      "Button_6" : [
        "bddd6c56-6e5e-4450-a606-2de09954a559",
        "ac50fc10-8047-4d4b-af81-1f247b5521e9"
      ]
    },
    "b3d47cbe-2b79-4d5d-b69c-35edd0509267" : {
      "Button_1" : [
        "b0a8598c-16e9-4231-8bdf-3e30f16e01df"
      ],
      "Button_2" : [
        "a4a2cb6f-8485-4418-842a-b76db19aa1cb"
      ],
      "Button_3" : [
        "e4df34a7-e082-4172-b666-bc3552a6a06f"
      ],
      "Category_1" : [
        "6cdbc05b-8711-40da-8fde-1d5dbf432ed3",
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Button_6" : [
        "bddd6c56-6e5e-4450-a606-2de09954a559",
        "ac50fc10-8047-4d4b-af81-1f247b5521e9"
      ]
    },
    "6cdbc05b-8711-40da-8fde-1d5dbf432ed3" : {
      "Button_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Category_1" : [
        "6cdbc05b-8711-40da-8fde-1d5dbf432ed3",
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Button_6" : [
        "bddd6c56-6e5e-4450-a606-2de09954a559",
        "ac50fc10-8047-4d4b-af81-1f247b5521e9"
      ]
    },
    "411aa969-ebe9-4a4a-bdb8-aa1ae7261e56" : {
      "Button_10" : [
        "411aa969-ebe9-4a4a-bdb8-aa1ae7261e56"
      ],
      "Category_1" : [
        "6cdbc05b-8711-40da-8fde-1d5dbf432ed3",
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Current_row_1" : [
        "3ad89b18-1b2f-4cdb-8b16-539dcf5a29d6"
      ],
      "Button_6" : [
        "bddd6c56-6e5e-4450-a606-2de09954a559",
        "ac50fc10-8047-4d4b-af81-1f247b5521e9"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Login" : [
        "bddd6c56-6e5e-4450-a606-2de09954a559",
        "ac50fc10-8047-4d4b-af81-1f247b5521e9"
      ]
    },
    "bddd6c56-6e5e-4450-a606-2de09954a559" : {
      "Button_1" : [
        "7ce23c92-760c-433a-bab0-872a1a3a91b2"
      ],
      "Button_2" : [
        "411aa969-ebe9-4a4a-bdb8-aa1ae7261e56"
      ],
      "Button_3" : [
        "b3d47cbe-2b79-4d5d-b69c-35edd0509267"
      ],
      "Category_1" : [
        "6cdbc05b-8711-40da-8fde-1d5dbf432ed3",
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "b0a8598c-16e9-4231-8bdf-3e30f16e01df" : {
      "Category_1" : [
        "6cdbc05b-8711-40da-8fde-1d5dbf432ed3",
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Current_row_1" : [
        "3ad89b18-1b2f-4cdb-8b16-539dcf5a29d6"
      ],
      "Button_6" : [
        "bddd6c56-6e5e-4450-a606-2de09954a559",
        "ac50fc10-8047-4d4b-af81-1f247b5521e9"
      ]
    },
    "8948928c-62d1-4fd3-bfe3-dbc70c2dc134" : {
      "Button_6" : [
        "bddd6c56-6e5e-4450-a606-2de09954a559",
        "ac50fc10-8047-4d4b-af81-1f247b5521e9"
      ],
      "Category_2" : [
        "6cdbc05b-8711-40da-8fde-1d5dbf432ed3",
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Button_4" : [
        "bddd6c56-6e5e-4450-a606-2de09954a559"
      ]
    },
    "7ce23c92-760c-433a-bab0-872a1a3a91b2" : {
      "Button_1" : [
        "7ce23c92-760c-433a-bab0-872a1a3a91b2"
      ],
      "Button_2" : [
        "bddd6c56-6e5e-4450-a606-2de09954a559"
      ],
      "Button_3" : [
        "7ce23c92-760c-433a-bab0-872a1a3a91b2"
      ],
      "Button_6" : [
        "bddd6c56-6e5e-4450-a606-2de09954a559"
      ],
      "Category_2" : [
        "6cdbc05b-8711-40da-8fde-1d5dbf432ed3",
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);