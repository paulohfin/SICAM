jQuery("#simulation")
  .on("click", ".s-7ce23c92-760c-433a-bab0-872a1a3a91b2 .click", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Input_5")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-7ce23c92-760c-433a-bab0-872a1a3a91b2 #s-Text_3": {
                      "attributes": {
                        "opacity": "0.5"
                      }
                    }
                  },{
                    "#s-7ce23c92-760c-433a-bab0-872a1a3a91b2 #s-Text_3": {
                      "attributes-ie": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=50)",
                        "filter": "alpha(opacity=50)"
                      }
                    }
                  },{
                    "#s-7ce23c92-760c-433a-bab0-872a1a3a91b2 #s-Text_3": {
                      "attributes-ie8lte": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=50)",
                        "filter": "alpha(opacity=50)"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Input_8")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-7ce23c92-760c-433a-bab0-872a1a3a91b2 #s-Text_6": {
                      "attributes": {
                        "opacity": "0.5"
                      }
                    }
                  },{
                    "#s-7ce23c92-760c-433a-bab0-872a1a3a91b2 #s-Text_6": {
                      "attributes-ie": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=50)",
                        "filter": "alpha(opacity=50)"
                      }
                    }
                  },{
                    "#s-7ce23c92-760c-433a-bab0-872a1a3a91b2 #s-Text_6": {
                      "attributes-ie8lte": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=50)",
                        "filter": "alpha(opacity=50)"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Input_7")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-7ce23c92-760c-433a-bab0-872a1a3a91b2 #s-Text_5": {
                      "attributes": {
                        "opacity": "0.5"
                      }
                    }
                  },{
                    "#s-7ce23c92-760c-433a-bab0-872a1a3a91b2 #s-Text_5": {
                      "attributes-ie": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=50)",
                        "filter": "alpha(opacity=50)"
                      }
                    }
                  },{
                    "#s-7ce23c92-760c-433a-bab0-872a1a3a91b2 #s-Text_5": {
                      "attributes-ie8lte": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=50)",
                        "filter": "alpha(opacity=50)"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Input_17")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-7ce23c92-760c-433a-bab0-872a1a3a91b2 #s-Text_15": {
                      "attributes": {
                        "opacity": "0.5"
                      }
                    }
                  },{
                    "#s-7ce23c92-760c-433a-bab0-872a1a3a91b2 #s-Text_15": {
                      "attributes-ie": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=50)",
                        "filter": "alpha(opacity=50)"
                      }
                    }
                  },{
                    "#s-7ce23c92-760c-433a-bab0-872a1a3a91b2 #s-Text_15": {
                      "attributes-ie8lte": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=50)",
                        "filter": "alpha(opacity=50)"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Input_16")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-7ce23c92-760c-433a-bab0-872a1a3a91b2 #s-Text_14": {
                      "attributes": {
                        "opacity": "0.5"
                      }
                    }
                  },{
                    "#s-7ce23c92-760c-433a-bab0-872a1a3a91b2 #s-Text_14": {
                      "attributes-ie": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=50)",
                        "filter": "alpha(opacity=50)"
                      }
                    }
                  },{
                    "#s-7ce23c92-760c-433a-bab0-872a1a3a91b2 #s-Text_14": {
                      "attributes-ie8lte": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=50)",
                        "filter": "alpha(opacity=50)"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Input_15")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-7ce23c92-760c-433a-bab0-872a1a3a91b2 #s-Text_13": {
                      "attributes": {
                        "opacity": "0.5"
                      }
                    }
                  },{
                    "#s-7ce23c92-760c-433a-bab0-872a1a3a91b2 #s-Text_13": {
                      "attributes-ie": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=50)",
                        "filter": "alpha(opacity=50)"
                      }
                    }
                  },{
                    "#s-7ce23c92-760c-433a-bab0-872a1a3a91b2 #s-Text_13": {
                      "attributes-ie8lte": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=50)",
                        "filter": "alpha(opacity=50)"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Input_6")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-7ce23c92-760c-433a-bab0-872a1a3a91b2 #s-Text_4": {
                      "attributes": {
                        "opacity": "0.5"
                      }
                    }
                  },{
                    "#s-7ce23c92-760c-433a-bab0-872a1a3a91b2 #s-Text_4": {
                      "attributes-ie": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=50)",
                        "filter": "alpha(opacity=50)"
                      }
                    }
                  },{
                    "#s-7ce23c92-760c-433a-bab0-872a1a3a91b2 #s-Text_4": {
                      "attributes-ie8lte": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=50)",
                        "filter": "alpha(opacity=50)"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Input_4")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-7ce23c92-760c-433a-bab0-872a1a3a91b2 #s-Text_1": {
                      "attributes": {
                        "opacity": "0.5"
                      }
                    }
                  },{
                    "#s-7ce23c92-760c-433a-bab0-872a1a3a91b2 #s-Text_1": {
                      "attributes-ie": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=50)",
                        "filter": "alpha(opacity=50)"
                      }
                    }
                  },{
                    "#s-7ce23c92-760c-433a-bab0-872a1a3a91b2 #s-Text_1": {
                      "attributes-ie8lte": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=50)",
                        "filter": "alpha(opacity=50)"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Input_3")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-7ce23c92-760c-433a-bab0-872a1a3a91b2 #s-Text_2": {
                      "attributes": {
                        "opacity": "0.5"
                      }
                    }
                  },{
                    "#s-7ce23c92-760c-433a-bab0-872a1a3a91b2 #s-Text_2": {
                      "attributes-ie": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=50)",
                        "filter": "alpha(opacity=50)"
                      }
                    }
                  },{
                    "#s-7ce23c92-760c-433a-bab0-872a1a3a91b2 #s-Text_2": {
                      "attributes-ie8lte": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=50)",
                        "filter": "alpha(opacity=50)"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Button_1")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "action": "jimEquals",
                "parameter": [ {
                  "action": "jimCount",
                  "parameter": [ {
                    "action": "jimFilterData",
                    "parameter": {
                      "datatype": "datamaster",
                      "datamaster": "Estagiario",
                      "value": {
                        "action": "jimEquals",
                        "parameter": [ {
                          "field": "CPF"
                        },{
                          "datatype": "property",
                          "target": "#s-Input_3",
                          "property": "jimGetValue"
                        } ]
                      }
                    }
                  } ]
                },"0" ]
              },
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Text_4","#s-Input_11","#s-Category_5","#s-Input_12","#s-Text_11","#s-Category_1","#s-Text_31","#s-Text_10","#s-Input_13","#s-Button_3","#s-Text_19","#s-Input_24","#s-Input_4","#s-Input_10","#s-Text_20","#s-Input_15","#s-Category_3","#s-Category_6","#s-Text_15","#s-Text_9","#s-Text_28","#s-Text_18","#s-Text_25","#s-Input_8","#s-Input_9","#s-Text_29","#s-Text_3","#s-Input_6","#s-Text_27","#s-Text_1","#s-Input_17","#s-Input_5","#s-Text_6","#s-Category_4","#s-Text_13","#s-Text_8","#s-Input_7","#s-Text_30","#s-Input_18","#s-Text_7","#s-Text_21","#s-Text_17","#s-Text_5","#s-Input_16","#s-Text_26","#s-Text_12","#s-Input_14","#s-Input_23","#s-Button_2","#s-Input_22","#s-Text_14" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            },
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/7ce23c92-760c-433a-bab0-872a1a3a91b2"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Button_1" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-7ce23c92-760c-433a-bab0-872a1a3a91b2 #s-Input_3": {
                      "attributes": {
                        "background-color": "#D9D9D9",
                        "background-image": "none"
                      }
                    }
                  },{
                    "#s-7ce23c92-760c-433a-bab0-872a1a3a91b2 #s-Input_3": {
                      "attributes-ie": {
                        "-pie-background": "#D9D9D9",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimDisable",
                  "parameter": {
                    "target": [ "#s-Input_3" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Button_2")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimCreateData",
                  "parameter": {
                    "datatype": "datamaster",
                    "datamaster": "Estagiario",
                    "fields": {
                      "NOME": {
                        "datatype": "property",
                        "target": "#s-Input_4",
                        "property": "jimGetValue"
                      },
                      "CPF": {
                        "datatype": "property",
                        "target": "#s-Input_3",
                        "property": "jimGetValue"
                      },
                      "TELEFONE1": {
                        "datatype": "property",
                        "target": "#s-Input_5",
                        "property": "jimGetValue"
                      },
                      "TELEFONE2": {
                        "datatype": "property",
                        "target": "#s-Input_6",
                        "property": "jimGetValue"
                      },
                      "ENDERECO": {
                        "datatype": "property",
                        "target": "#s-Input_15",
                        "property": "jimGetValue"
                      },
                      "COMPLEMENTO": {
                        "datatype": "property",
                        "target": "#s-Input_16",
                        "property": "jimGetValue"
                      },
                      "SETOR": {
                        "datatype": "property",
                        "target": "#s-Input_17",
                        "property": "jimGetValue"
                      },
                      "BANCO": {
                        "datatype": "property",
                        "target": "#s-Input_11",
                        "property": "jimGetValue"
                      },
                      "AGENCIA": {
                        "datatype": "property",
                        "target": "#s-Input_22",
                        "property": "jimGetValue"
                      },
                      "OPERACAO": {
                        "datatype": "property",
                        "target": "#s-Input_23",
                        "property": "jimGetValue"
                      },
                      "CONTA": {
                        "datatype": "property",
                        "target": "#s-Input_12",
                        "property": "jimGetValue"
                      },
                      "CURSO": {
                        "datatype": "property",
                        "target": "#s-Input_7",
                        "property": "jimGetValue"
                      },
                      "INSTITUICAO": {
                        "datatype": "property",
                        "target": "#s-Input_8",
                        "property": "jimGetValue"
                      },
                      "INICIOCONTRATO": {
                        "datatype": "property",
                        "target": "#s-Input_9",
                        "property": "jimGetValue"
                      },
                      "TERMINOCONTRATO": {
                        "datatype": "property",
                        "target": "#s-Input_10",
                        "property": "jimGetValue"
                      },
                      "VALORESTAGIO": {
                        "datatype": "property",
                        "target": "#s-Input_18",
                        "property": "jimGetValue"
                      },
                      "LOTACAO": {
                        "datatype": "property",
                        "target": "#s-Category_1",
                        "property": "jimGetSelectedValue"
                      },
                      "SUPERVISOR": {
                        "datatype": "property",
                        "target": "#s-Category_5",
                        "property": "jimGetSelectedValue"
                      },
                      "CONVENIO": {
                        "datatype": "property",
                        "target": "#s-Category_4",
                        "property": "jimGetSelectedValue"
                      },
                      "LOGIN": {
                        "datatype": "property",
                        "target": "#s-Input_24",
                        "property": "jimGetValue"
                      },
                      "SENHA": "123456",
                      "SITUACAOCONTRATO": {
                        "datatype": "property",
                        "target": "#s-Category_3",
                        "property": "jimGetSelectedValue"
                      },
                      "CONVENIOANTERIOR": {
                        "datatype": "property",
                        "target": "#s-Category_6",
                        "property": "jimGetSelectedValue"
                      },
                      "DATAINICIOANTERIOR": {
                        "datatype": "property",
                        "target": "#s-Input_13",
                        "property": "jimGetValue"
                      },
                      "DATAFIMANTERIOR": {
                        "datatype": "property",
                        "target": "#s-Input_14",
                        "property": "jimGetValue"
                      },
                      "VALOR": null,
                      "INICIOFERIAS": null,
                      "TERMINOFERIAS": null
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/bddd6c56-6e5e-4450-a606-2de09954a559"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Button_3")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/7ce23c92-760c-433a-bab0-872a1a3a91b2"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Button_6")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/bddd6c56-6e5e-4450-a606-2de09954a559"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Input_23")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-7ce23c92-760c-433a-bab0-872a1a3a91b2 #s-Text_28": {
                      "attributes": {
                        "opacity": "0.5"
                      }
                    }
                  },{
                    "#s-7ce23c92-760c-433a-bab0-872a1a3a91b2 #s-Text_28": {
                      "attributes-ie": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=50)",
                        "filter": "alpha(opacity=50)"
                      }
                    }
                  },{
                    "#s-7ce23c92-760c-433a-bab0-872a1a3a91b2 #s-Text_28": {
                      "attributes-ie8lte": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=50)",
                        "filter": "alpha(opacity=50)"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Input_22")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-7ce23c92-760c-433a-bab0-872a1a3a91b2 #s-Text_25": {
                      "attributes": {
                        "opacity": "0.5"
                      }
                    }
                  },{
                    "#s-7ce23c92-760c-433a-bab0-872a1a3a91b2 #s-Text_25": {
                      "attributes-ie": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=50)",
                        "filter": "alpha(opacity=50)"
                      }
                    }
                  },{
                    "#s-7ce23c92-760c-433a-bab0-872a1a3a91b2 #s-Text_25": {
                      "attributes-ie8lte": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=50)",
                        "filter": "alpha(opacity=50)"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Input_12")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-7ce23c92-760c-433a-bab0-872a1a3a91b2 #s-Text_26": {
                      "attributes": {
                        "opacity": "0.5"
                      }
                    }
                  },{
                    "#s-7ce23c92-760c-433a-bab0-872a1a3a91b2 #s-Text_26": {
                      "attributes-ie": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=50)",
                        "filter": "alpha(opacity=50)"
                      }
                    }
                  },{
                    "#s-7ce23c92-760c-433a-bab0-872a1a3a91b2 #s-Text_26": {
                      "attributes-ie8lte": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=50)",
                        "filter": "alpha(opacity=50)"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Input_11")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-7ce23c92-760c-433a-bab0-872a1a3a91b2 #s-Text_27": {
                      "attributes": {
                        "opacity": "0.5"
                      }
                    }
                  },{
                    "#s-7ce23c92-760c-433a-bab0-872a1a3a91b2 #s-Text_27": {
                      "attributes-ie": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=50)",
                        "filter": "alpha(opacity=50)"
                      }
                    }
                  },{
                    "#s-7ce23c92-760c-433a-bab0-872a1a3a91b2 #s-Text_27": {
                      "attributes-ie8lte": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=50)",
                        "filter": "alpha(opacity=50)"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Input_18")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-7ce23c92-760c-433a-bab0-872a1a3a91b2 #s-Text_18": {
                      "attributes": {
                        "opacity": "0.5"
                      }
                    }
                  },{
                    "#s-7ce23c92-760c-433a-bab0-872a1a3a91b2 #s-Text_18": {
                      "attributes-ie": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=50)",
                        "filter": "alpha(opacity=50)"
                      }
                    }
                  },{
                    "#s-7ce23c92-760c-433a-bab0-872a1a3a91b2 #s-Text_18": {
                      "attributes-ie8lte": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=50)",
                        "filter": "alpha(opacity=50)"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Input_24")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-7ce23c92-760c-433a-bab0-872a1a3a91b2 #s-Text_29": {
                      "attributes": {
                        "opacity": "0.5"
                      }
                    }
                  },{
                    "#s-7ce23c92-760c-433a-bab0-872a1a3a91b2 #s-Text_29": {
                      "attributes-ie": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=50)",
                        "filter": "alpha(opacity=50)"
                      }
                    }
                  },{
                    "#s-7ce23c92-760c-433a-bab0-872a1a3a91b2 #s-Text_29": {
                      "attributes-ie8lte": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=50)",
                        "filter": "alpha(opacity=50)"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_29")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-7ce23c92-760c-433a-bab0-872a1a3a91b2 #s-Text_29": {
                      "attributes": {
                        "opacity": "0.5"
                      }
                    }
                  },{
                    "#s-7ce23c92-760c-433a-bab0-872a1a3a91b2 #s-Text_29": {
                      "attributes-ie": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=50)",
                        "filter": "alpha(opacity=50)"
                      }
                    }
                  },{
                    "#s-7ce23c92-760c-433a-bab0-872a1a3a91b2 #s-Text_29": {
                      "attributes-ie8lte": {
                        "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=50)",
                        "filter": "alpha(opacity=50)"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Category_2")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "action": "jimEquals",
                "parameter": [ {
                  "datatype": "property",
                  "target": "#s-Category_2",
                  "property": "jimGetSelectedValue"
                },"Trocar Senha" ]
              },
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/6cdbc05b-8711-40da-8fde-1d5dbf432ed3"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "condition": {
                "action": "jimEquals",
                "parameter": [ {
                  "datatype": "property",
                  "target": "#s-Category_2",
                  "property": "jimGetSelectedValue"
                },"Sair" ]
              },
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/d12245cc-1680-458d-89dd-4f0d7fb22724"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Category_5")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Category_5" ],
                    "value": {
                      "action": "jimSelectData",
                      "parameter": {
                        "datatype": "datamaster",
                        "datamaster": "Servidor",
                        "value": {
                          "field": "NOME"
                        }
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  });